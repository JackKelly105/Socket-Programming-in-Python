#!/usr/bin/env python
#TeamJ_JackKelly(K00236610)_TzerKaeLeong(K00243630)_
#NeilGerardFranklin(K00233505)_server2
import socket
import sys
import math

#creating a socket for server
server2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
if(server2<0):
	print("Socket is not created")
	sys.exit()
print ("Socket is created successfully.")
#defining the port number and host ip
port = 1050
host = "127.0.0.1"
#binding with host ip and port number
server2.bind((host,port))
#defining variables
numbers=[]
result=False
counter =0
#listening connection from client to server
print "Waiting for connection..."
server2.listen(1)

while True:
	connection, address = server2.accept()
	#displaying where the server connected from
	print "Connecting from "+ str(address)

	while(counter <=3):
		numbers.insert(counter,connection.recv(1024))
		counter = counter+1
	try:
		#using a map that executes the input for each variable in the 			list and converts the inputs to integers
		numbers = list(map(int,numbers))
		for x in numbers:
			#check if the input is the power of two
			if(math.log(x,2).is_integer()):
				result=True
			else:
				result=False
				break

		print "Result is out!"
		if(result==True):
			connection.send('The 4 inputs are the powers of 2.')
		else:
			connection.send('The 4 inputs are not the powers of 2.')
	finally:
		connection.close()
		print "Connection is terminated."
		exit(1)
	
