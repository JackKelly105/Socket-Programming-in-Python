#!/usr/bin/env python
#TeamJ_JackKelly(K00236610)_TzerKaeLeong(K00243630)_
#NeilGerardFranklin(K00233505)_server1
import socket
import sys

#creating a socket for server
server1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
if(server1<0):
	print("Socket is not created")
	sys.exit()
print ("Socket is created successfully.")
#defining the port number and host ip
port = 1050
host = "127.0.0.1"
#binding with host ip and port number
server1.bind((host,port))
#listening connection from client to server
print "Waiting for connection..."
server1.listen(1)

while True:
	connection, address = server1.accept()
	#displaying where the server connected from
	print "Connecting from "+ str(address)
	name = connection.recv(1024)
	try:
		#check if the input is string
		if (name.isalpha()):
			connection.send("The name "+name+" is validated.")
			print "Result is out!"
		else:
			connection.send("Invalid name.")
			print "Result is invalid."
	finally:
		connection.close()
		print "Connection is terminated."
		exit(1)
