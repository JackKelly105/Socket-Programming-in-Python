#!/usr/bin/env python
#TeamJ_JackKelly(K00236610)_TzerKaeLeong(K00243630)_
#NeilGerardFranklin(K00233505)_client2

import socket
import sys

#creating a socket for client
client2 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
if(client2<0):
	print("Socket is not created.")
	sys.exit()

print("Socket is created successfully.")
#defining the port number and host ip
port=1050
host = "127.0.0.1"
#connecting from client to the server
client2.connect((host,port))
print ("Connected to the server.")
counter = 1

try:
	while (counter <=4):
		#Prompt user to enter 4 numbers from keyboard
		number = raw_input("Enter a number: ")
		#send the input to the server
		client2.send(number)
		counter= counter+1
	#print out whatever send from the server
	print client2.recv(1024)
finally:
	client2.close()
