#!/usr/bin/env python
#TeamJ_JackKelly(K00236610)_TzerKaeLeong(K00243630)_
#NeilGerardFranklin(K00233505)_client1
import socket
import sys

#creating a socket for client
client1 = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
if(client1<0):
	print("Socket is not created.")
	sys.exit()

print("Socket is created successfully.")
#defining the port number and host ip
port=1050
host = "127.0.0.1"
#connecting from client to the server
client1.connect((host,port))
print ("Connected to the server.")

try:
	#Prompt user to enter name from keyboard
	name = raw_input("Enter your name: ")
	#send the input to the server
	client1.send(name.encode())
	#print out whatever send from the server
	print client1.recv(1024)
finally:
	client1.close()
